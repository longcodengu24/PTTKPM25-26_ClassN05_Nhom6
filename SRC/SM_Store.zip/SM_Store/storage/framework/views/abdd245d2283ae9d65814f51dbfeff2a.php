<?php $__env->startSection('content'); ?>
   chào 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\app\laragon\www\cayvlon\PTTKPM25-26_ClassN05_Nhom6\SRC\SM_Store\resources\views/account/index.blade.php ENDPATH**/ ?>